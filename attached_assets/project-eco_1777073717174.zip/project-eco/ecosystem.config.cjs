module.exports = {
  apps: [
    {
      name: 'eco-civ-1',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '1',
        CHANNEL_NAME: 'Civilian RTO #1',
        CHANNEL_TYPE: 'civilian',
      },
    },
    {
      name: 'eco-civ-2',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '2',
        CHANNEL_NAME: 'Civilian RTO #2',
        CHANNEL_TYPE: 'civilian',
      },
    },
    {
      name: 'eco-civ-3',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '3',
        CHANNEL_NAME: 'Civilian RTO #3',
        CHANNEL_TYPE: 'civilian',
      },
    },
    {
      name: 'eco-civ-4',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '4',
        CHANNEL_NAME: 'Civilian RTO #4',
        CHANNEL_TYPE: 'civilian',
      },
    },
    {
      name: 'eco-civ-5',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '5',
        CHANNEL_NAME: 'Civilian RTO #5',
        CHANNEL_TYPE: 'civilian',
      },
    },
    {
      name: 'eco-civ-6',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '6',
        CHANNEL_NAME: 'Civilian RTO #6',
        CHANNEL_TYPE: 'civilian',
      },
    },
    {
      name: 'eco-stop-1',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '7',
        CHANNEL_NAME: 'Traffic Stop #1',
        CHANNEL_TYPE: 'trafficstop',
      },
    },
    {
      name: 'eco-stop-2',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '8',
        CHANNEL_NAME: 'Traffic Stop #2',
        CHANNEL_TYPE: 'trafficstop',
      },
    },
    {
      name: 'eco-stop-3',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '9',
        CHANNEL_NAME: 'Traffic Stop #3',
        CHANNEL_TYPE: 'trafficstop',
      },
    },
    {
      name: 'eco-stop-4',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '10',
        CHANNEL_NAME: 'Traffic Stop #4',
        CHANNEL_TYPE: 'trafficstop',
      },
    },
    {
      name: 'eco-stop-5',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '11',
        CHANNEL_NAME: 'Traffic Stop #5',
        CHANNEL_TYPE: 'trafficstop',
      },
    },
    {
      name: 'eco-fd-rto',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      env: {
        BOT_INDEX: '12',
        CHANNEL_NAME: 'FD RTO',
        CHANNEL_TYPE: 'fd',
      },
    },
  ],
};
