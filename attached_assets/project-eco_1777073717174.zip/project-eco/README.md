# Project Eco — Palm Springs RP

AI voice assistant bots for Palm Springs RP. 12 bots running from one codebase, each permanently assigned to a voice channel.

## Channel Assignments

| Bot | Channel | Type |
|-----|---------|------|
| Eco 1 | Civilian RTO #1 | Civilian |
| Eco 2 | Civilian RTO #2 | Civilian |
| Eco 3 | Civilian RTO #3 | Civilian |
| Eco 4 | Civilian RTO #4 | Civilian |
| Eco 5 | Civilian RTO #5 | Civilian |
| Eco 6 | Civilian RTO #6 | Civilian |
| Eco 7 | Traffic Stop #1 | Traffic Stop |
| Eco 8 | Traffic Stop #2 | Traffic Stop |
| Eco 9 | Traffic Stop #3 | Traffic Stop |
| Eco 10 | Traffic Stop #4 | Traffic Stop |
| Eco 11 | Traffic Stop #5 | Traffic Stop |
| Eco 12 | FD RTO | Fire Department |

## What Eco Can Do

Members say "Eco" or "Hey Eco" followed by a command:

- **911 call** — "Eco 911 robbery at the bank"
- **Priority request** — "Eco priority request"
- **Run plates** — "Eco run plates ABC123"
- **Run a name** — "Eco run the name John Smith"

All commands are processed via shared MongoDB so RolePlayManager sees them instantly.

## Setup

### 1. Create 12 Discord Bots
Go to https://discord.com/developers/applications and create 12 new apps. Name them all "Eco" or "Project Eco". Copy each bot token.

Enable these intents for each bot:
- Server Members Intent
- Voice Activity (no privileged intent needed)

### 2. Invite all 12 bots to your server
Use this URL for each (replace CLIENT_ID):
```
https://discord.com/oauth2/authorize?client_id=CLIENT_ID&permissions=3148800&scope=bot
```

### 3. Set up environment variables
Copy `.env.example` to `.env` and fill in all values:
- All 12 bot tokens
- All 12 voice channel IDs (right click channel → Copy ID)
- Your server/guild ID
- Your MongoDB URI (same as RolePlayManager)
- Your Groq API keys
- Your dispatch channel ID

### 4. Deploy to Koyeb
- Push this repo to GitHub
- Create a new Koyeb service from the repo
- Add all environment variables from your .env
- Set start command to: `npm start`
- Koyeb runs PM2 which starts all 12 bots automatically

## How It Connects to RolePlayManager

Both bots share the same MongoDB database. When Eco receives a voice command it writes to the same collections RolePlayManager uses (EmergencyCall, PriorityRequest etc). RolePlayManager picks them up and handles them exactly like commands typed in Discord.

## Trigger Word

Members say **"Eco"** or **"Hey Eco"** to trigger a command. Without the trigger word Eco stays silent.
