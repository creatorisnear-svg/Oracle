import { Schema, model } from 'mongoose';

// ── Emergency Call (911) ─────────────────────────────────────────────────────
// Same schema as RolePlayManager so Eco writes calls that RPM picks up
const emergencyCallSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  callId: { type: String, required: true, unique: true },
  issue: String,
  location: String,
  suspectsDescription: String,
  lastSeen: String,
  contact: String,
  reporterUsername: String,
  reporterId: String,
  timestamp: { type: Date, default: Date.now },
  status: { type: String, enum: ['active', 'closed'], default: 'active' },
  respondingLeoId: String,
  respondingLeoUsername: String,
  attachedLeoIds: { type: [String], default: [] },
  closedAt: Date,
  closedBy: String,
  messageId: String,
  channelId: String,
  source: { type: String, default: 'eco' }, // marks this call came from Project Eco
});

export const EmergencyCall = model('EmergencyCall', emergencyCallSchema);

// ── Priority Request ─────────────────────────────────────────────────────────
const prioritySchema = new Schema({
  guildId: { type: String, required: true, unique: true },
  enabled: { type: Boolean, default: false },
  channelId: { type: String, default: null },
  messageId: { type: String, default: null },
  customMessage: { type: String, default: null },
  priorityActive: { type: Boolean, default: false },
  priorityIssuedBy: { type: String, default: null },
  cooldownMinutes: { type: Number, default: 0 },
  cooldownEndsAt: { type: Date, default: null },
  cooldownIssuedBy: { type: String, default: null },
  activatedAt: { type: Date, default: null },
  expiresAt: { type: Date, default: null },
  hostUserId: { type: String, default: null },
  requestedByUserId: { type: String, default: null },
});

export const Priority = model('Priority', prioritySchema);

// ── Priority Request Queue ───────────────────────────────────────────────────
const priorityRequestSchema = new Schema({
  guildId: { type: String, required: true },
  requesterId: { type: String, required: true },
  requesterUsername: { type: String },
  sceneType: { type: String },
  sceneReason: { type: String },
  memberId: { type: String },
  hostId: { type: String },
  status: { type: String, enum: ['pending', 'approved', 'denied'], default: 'pending' },
  timestamp: { type: Date, default: Date.now },
  messageId: { type: String },
  source: { type: String, default: 'eco' },
});

export const PriorityRequest = model('PriorityRequest', priorityRequestSchema);

// ── CAD Character (for plate and name lookups) ───────────────────────────────
const cadCharacterSchema = new Schema({
  guildId: { type: String, required: true },
  userId: { type: String, required: true },
  characterName: { type: String },
  age: { type: String },
  gender: { type: String },
  status: { type: String, default: 'clean' },
  driverLicenseStatus: { type: String, default: 'valid' },
  licensePlate: { type: String },
  vehicles: [{
    make: String,
    model: String,
    color: String,
    year: String,
    licensePlate: String,
    condition: String,
  }],
  guns: [{ type: String }],
  specialStatus: { type: String },
});

export const CADCharacter = model('CADCharacter', cadCharacterSchema);

// ── BOLO ─────────────────────────────────────────────────────────────────────
const boloSchema = new Schema({
  guildId: { type: String, required: true },
  characterId: { type: Schema.Types.ObjectId, ref: 'CADCharacter' },
  reason: { type: String },
  active: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
});

export const BOLO = model('BOLO', boloSchema);

// ── Dispatch Config ──────────────────────────────────────────────────────────
const dispatchConfigSchema = new Schema({
  guildId: { type: String, required: true, unique: true },
  enabled: { type: Boolean, default: false },
  aiEnabled: { type: Boolean, default: true },
  dispatchChannelId: { type: String, default: null },
  leoRoleIds: { type: [String], default: [] },
  patrolChannelIds: { type: [String], default: [] },
  trafficStopChannelIds: { type: [String], default: [] },
});

export const DispatchConfig = model('DispatchConfig', dispatchConfigSchema);
