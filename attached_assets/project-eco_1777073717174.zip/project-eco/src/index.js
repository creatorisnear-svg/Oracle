import { Client, GatewayIntentBits, Events } from 'discord.js';
import dotenv from 'dotenv';
import express from 'express';
import { connectDatabase } from './database.js';
import { joinChannel } from './voiceListener.js';

dotenv.config();

const BOT_INDEX = process.env.BOT_INDEX || '1';
const CHANNEL_NAME = process.env.CHANNEL_NAME || 'Unknown';
const CHANNEL_TYPE = process.env.CHANNEL_TYPE || 'civilian';
const GUILD_ID = process.env.GUILD_ID;

const BOT_TOKEN = process.env[`BOT_TOKEN_${BOT_INDEX}`];
const CHANNEL_ID = process.env[`CHANNEL_ID_${BOT_INDEX}`];

if (!BOT_TOKEN) {
  console.error(`[Eco Bot ${BOT_INDEX}] No token found. Set BOT_TOKEN_${BOT_INDEX} in .env`);
  process.exit(1);
}

if (!CHANNEL_ID) {
  console.error(`[Eco Bot ${BOT_INDEX}] No channel ID found. Set CHANNEL_ID_${BOT_INDEX} in .env`);
  process.exit(1);
}

// ── Discord client ────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
  ],
});

// ── On ready — join assigned channel ─────────────────────────────────────────
client.once(Events.ClientReady, async () => {
  console.log(`[Eco Bot ${BOT_INDEX}] Online as ${client.user.tag} — assigned to ${CHANNEL_NAME}`);
  await connectDatabase();
  await joinAssignedChannel();
});

async function joinAssignedChannel() {
  try {
    const guild = await client.guilds.fetch(GUILD_ID);
    if (!guild) {
      console.error(`[Eco Bot ${BOT_INDEX}] Guild ${GUILD_ID} not found`);
      return;
    }

    const channel = await client.channels.fetch(CHANNEL_ID);
    if (!channel) {
      console.error(`[Eco Bot ${BOT_INDEX}] Channel ${CHANNEL_ID} not found`);
      return;
    }

    if (channel.type !== 2) { // 2 = GuildVoice
      console.error(`[Eco Bot ${BOT_INDEX}] Channel ${CHANNEL_ID} is not a voice channel`);
      return;
    }

    await joinChannel(channel, client);
    console.log(`[Eco Bot ${BOT_INDEX}] Joined ${CHANNEL_NAME} successfully`);
  } catch (err) {
    console.error(`[Eco Bot ${BOT_INDEX}] Error joining channel:`, err.message);
    // Retry after 15 seconds
    setTimeout(joinAssignedChannel, 15000);
  }
}

// ── Rejoin if kicked from voice ───────────────────────────────────────────────
client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
  if (newState.member?.user?.id !== client.user.id) return;
  if (oldState.channelId && !newState.channelId) {
    console.log(`[Eco Bot ${BOT_INDEX}] Kicked from voice, rejoining in 5 seconds...`);
    setTimeout(joinAssignedChannel, 5000);
  }
});

// ── Keep alive Express server for Koyeb ──────────────────────────────────────
// Only bot 1 runs the HTTP server to avoid port conflicts
if (BOT_INDEX === '1') {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.get('/', (req, res) => {
    res.json({
      status: 'online',
      project: 'Project Eco',
      server: 'Palm Springs RP',
      bots: 12,
    });
  });

  app.get('/health', (req, res) => res.send('OK'));

  app.listen(PORT, () => {
    console.log(`[Eco] Keep-alive server running on port ${PORT}`);
  });
}

// ── Login ─────────────────────────────────────────────────────────────────────
client.login(BOT_TOKEN).catch((err) => {
  console.error(`[Eco Bot ${BOT_INDEX}] Login failed:`, err.message);
  process.exit(1);
});
