import {
  joinVoiceChannel,
  EndBehaviorType,
  VoiceConnectionStatus,
  entersState,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  StreamType,
} from '@discordjs/voice';
import { Readable } from 'stream';
import prism from 'prism-media';
import { getAIClient, rotateGroqKey } from './aiClient.js';
import { isEcoCommand, handleEcoCommand } from './ecoHandler.js';

const BOT_INDEX = process.env.BOT_INDEX || '1';
const CHANNEL_NAME = process.env.CHANNEL_NAME || 'Unknown';

let voiceConnection = null;
let audioPlayer = null;
const recordingUsers = new Set();
const ttsQueue = [];
let ttsPlaying = false;

// ── Join the assigned voice channel ──────────────────────────────────────────
export async function joinChannel(channel, client) {
  if (voiceConnection) {
    try { voiceConnection.destroy(); } catch {}
    voiceConnection = null;
  }

  console.log(`[Eco Bot ${BOT_INDEX}] Joining ${CHANNEL_NAME} (${channel.id})`);

  voiceConnection = joinVoiceChannel({
    channelId: channel.id,
    guildId: channel.guild.id,
    adapterCreator: channel.guild.voiceAdapterCreator,
    selfDeaf: false,
    selfMute: false,
  });

  voiceConnection.on(VoiceConnectionStatus.Disconnected, async () => {
    console.log(`[Eco Bot ${BOT_INDEX}] Disconnected, attempting reconnect...`);
    try {
      await Promise.race([
        entersState(voiceConnection, VoiceConnectionStatus.Signalling, 5000),
        entersState(voiceConnection, VoiceConnectionStatus.Connecting, 5000),
      ]);
    } catch {
      setTimeout(() => joinChannel(channel, client), 10000);
    }
  });

  voiceConnection.on(VoiceConnectionStatus.Ready, () => {
    console.log(`[Eco Bot ${BOT_INDEX}] Ready in ${CHANNEL_NAME}`);
    startListening(channel.guild, client);
  });

  return voiceConnection;
}

// ── Start listening to all users in the channel ───────────────────────────────
function startListening(guild, client) {
  if (!voiceConnection) return;
  const receiver = voiceConnection.receiver;

  receiver.speaking.on('start', (userId) => {
    if (recordingUsers.has(userId)) return;
    recordingUsers.add(userId);
    recordUser(userId, guild, client, receiver);
  });
}

// ── Record a single user's audio and transcribe it ───────────────────────────
function recordUser(userId, guild, client, receiver) {
  const pcmChunks = [];
  let silenceTimer = null;

  const opusStream = receiver.subscribe(userId, {
    end: { behavior: EndBehaviorType.AfterSilence, duration: 800 },
  });

  const decoder = new prism.opus.Decoder({ rate: 48000, channels: 2, frameSize: 960 });
  opusStream.pipe(decoder);

  decoder.on('data', (chunk) => {
    pcmChunks.push(chunk);
    if (silenceTimer) clearTimeout(silenceTimer);
    silenceTimer = setTimeout(() => {}, 500);
  });

  decoder.on('end', async () => {
    recordingUsers.delete(userId);
    if (pcmChunks.length === 0) return;

    const wav = createWavBuffer(pcmChunks);
    if (wav.length < 5000) return; // too short, skip

    try {
      const transcript = await transcribeAudio(wav);
      if (!transcript || transcript.trim().length < 2) return;

      console.log(`[Eco Bot ${BOT_INDEX}] Transcript from ${userId}: "${transcript}"`);

      if (isEcoCommand(transcript)) {
        const result = await handleEcoCommand(transcript, userId, guild, client);
        if (result?.tts) {
          await speakTTS(result.tts);
        }
      }
    } catch (err) {
      console.error(`[Eco Bot ${BOT_INDEX}] Transcription/command error:`, err.message);
    }
  });

  decoder.on('error', () => recordingUsers.delete(userId));
  opusStream.on('error', () => recordingUsers.delete(userId));
}

// ── Transcribe audio using Groq Whisper ──────────────────────────────────────
async function transcribeAudio(wavBuffer) {
  const { client, provider } = getAIClient();
  const maxTries = 3;

  for (let attempt = 0; attempt < maxTries; attempt++) {
    try {
      const file = new File([wavBuffer], 'audio.wav', { type: 'audio/wav' });
      const response = await client.audio.transcriptions.create({
        model: 'whisper-large-v3',
        file,
        response_format: 'text',
      });
      return typeof response === 'string' ? response : response?.text || '';
    } catch (err) {
      if (err.status === 429 && rotateGroqKey()) {
        console.log(`[Eco Bot ${BOT_INDEX}] Rate limited, rotating key...`);
        continue;
      }
      throw err;
    }
  }
  return null;
}

// ── TTS — generate and queue speech ──────────────────────────────────────────
export async function speakTTS(text) {
  ttsQueue.push(text);
  if (!ttsPlaying) processTTSQueue();
}

async function processTTSQueue() {
  if (ttsQueue.length === 0) { ttsPlaying = false; return; }
  ttsPlaying = true;

  const text = ttsQueue.shift();
  try {
    const audioBuffer = await generateTTS(text);
    if (audioBuffer && voiceConnection) {
      await playAudio(audioBuffer);
    }
  } catch (err) {
    console.error(`[Eco Bot ${BOT_INDEX}] TTS error:`, err.message);
  }

  processTTSQueue();
}

async function generateTTS(text) {
  const maxTries = 3;
  for (let attempt = 0; attempt < maxTries; attempt++) {
    try {
      const { client } = getAIClient();
      const response = await client.audio.speech.create({
        model: 'canopylabs/orpheus-v1-english',
        voice: 'tara',
        input: text,
        response_format: 'wav',
      });
      const arrayBuffer = await response.arrayBuffer();
      return Buffer.from(arrayBuffer);
    } catch (err) {
      if (err.status === 429 && rotateGroqKey()) continue;
      throw err;
    }
  }
  return null;
}

async function playAudio(audioBuffer) {
  if (!voiceConnection) return;
  return new Promise((resolve) => {
    try {
      const player = createAudioPlayer();
      audioPlayer = player;

      const bufferStream = new Readable();
      bufferStream.push(audioBuffer);
      bufferStream.push(null);

      const isOgg = audioBuffer.length >= 4 && audioBuffer.toString('ascii', 0, 4) === 'OggS';
      const resource = createAudioResource(bufferStream, {
        inputType: isOgg ? StreamType.OggOpus : StreamType.Arbitrary,
      });

      voiceConnection.subscribe(player);
      player.play(resource);

      player.on('error', () => { audioPlayer = null; resolve(); });
      player.on(AudioPlayerStatus.Idle, () => { audioPlayer = null; resolve(); });
    } catch (err) {
      console.error(`[Eco Bot ${BOT_INDEX}] Audio play error:`, err.message);
      resolve();
    }
  });
}

// ── WAV buffer builder ────────────────────────────────────────────────────────
function createWavBuffer(pcmChunks) {
  const pcmData = Buffer.concat(pcmChunks);
  const numChannels = 2;
  const sampleRate = 48000;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;

  const header = Buffer.alloc(44);
  let o = 0;
  header.write('RIFF', o); o += 4;
  header.writeUInt32LE(36 + pcmData.length, o); o += 4;
  header.write('WAVE', o); o += 4;
  header.write('fmt ', o); o += 4;
  header.writeUInt32LE(16, o); o += 4;
  header.writeUInt16LE(1, o); o += 2;
  header.writeUInt16LE(numChannels, o); o += 2;
  header.writeUInt32LE(sampleRate, o); o += 4;
  header.writeUInt32LE(byteRate, o); o += 4;
  header.writeUInt16LE(blockAlign, o); o += 2;
  header.writeUInt16LE(bitsPerSample, o); o += 2;
  header.write('data', o); o += 4;
  header.writeUInt32LE(pcmData.length, o);

  return Buffer.concat([header, pcmData]);
}
