import OpenAI from 'openai';
import dotenv from 'dotenv';
dotenv.config();

let groqKeys = [];
let currentGroqKeyIndex = 0;
let groqKeysLoaded = false;

function loadGroqKeys() {
  const keys = [];
  const primary = process.env.GROQ_API_KEY;
  if (primary) keys.push(primary);
  for (let i = 1; i <= 10; i++) {
    const k = process.env[`GROQ_API_KEY_${i}`];
    if (k) keys.push(k);
  }
  const unique = [...new Set(keys)];
  if (unique.length !== groqKeys.length || unique.some((k, i) => k !== groqKeys[i])) {
    groqKeys = unique;
    if (currentGroqKeyIndex >= groqKeys.length) currentGroqKeyIndex = 0;
  }
  groqKeysLoaded = true;
  return groqKeys;
}

export function rotateGroqKey() {
  if (groqKeys.length <= 1) return false;
  const prev = currentGroqKeyIndex;
  currentGroqKeyIndex = (currentGroqKeyIndex + 1) % groqKeys.length;
  console.log(`[Eco AI] Rotated Groq key: slot ${prev + 1} → slot ${currentGroqKeyIndex + 1} of ${groqKeys.length}`);
  return true;
}

export function getAIClient() {
  if (!groqKeysLoaded) loadGroqKeys();
  if (groqKeys.length > 0) {
    const key = groqKeys[currentGroqKeyIndex];
    return {
      client: new OpenAI({ apiKey: key, baseURL: 'https://api.groq.com/openai/v1' }),
      provider: 'groq',
    };
  }
  throw new Error('No Groq API key configured. Set GROQ_API_KEY in your .env file.');
}

export function hasAIKey() {
  if (!groqKeysLoaded) loadGroqKeys();
  return groqKeys.length > 0;
}
