import { v4 as uuidv4 } from 'uuid';
import { EmbedBuilder } from 'discord.js';
import { EmergencyCall, Priority, PriorityRequest, DispatchConfig } from './models.js';
import { detectCADLookup, runCADLookup } from './cadLookup.js';

const BOT_INDEX = process.env.BOT_INDEX || '1';
const GUILD_ID = process.env.GUILD_ID;
const CHANNEL_TYPE = process.env.CHANNEL_TYPE || 'civilian';

// ── Check if transcript is directed at Eco ───────────────────────────────────
export function isEcoCommand(text) {
  const lower = text.toLowerCase().trim();
  return (
    lower.startsWith('eco ') ||
    lower.startsWith('hey eco') ||
    lower.startsWith('eco,') ||
    lower === 'eco'
  );
}

// ── Strip the trigger word and return the actual command ─────────────────────
function extractCommand(text) {
  return text
    .replace(/^hey\s+eco[,\s]*/i, '')
    .replace(/^eco[,\s]*/i, '')
    .trim();
}

// ── Main handler — routes command to correct action ──────────────────────────
export async function handleEcoCommand(transcript, userId, guild, client) {
  const command = extractCommand(transcript).toLowerCase();
  console.log(`[Eco Bot ${BOT_INDEX}] Command from ${userId}: "${command}"`);

  // 911 call
  if (command.includes('911') || command.includes('nine one one') || command.includes('emergency')) {
    return await handle911(command, userId, guild, client);
  }

  // Priority request
  if (command.includes('priority') || command.includes('priority request')) {
    return await handlePriorityRequest(command, userId, guild, client);
  }

  // Plate or name lookup
  const cadLookup = detectCADLookup(command);
  if (cadLookup) {
    return await handleCADLookup(cadLookup, guild, client);
  }

  // Unknown command — give helpful response
  return {
    tts: `Copy. I can handle 911 calls, priority requests, plate runs, and name checks. What do you need?`,
    embed: null,
  };
}

// ── 911 Call ─────────────────────────────────────────────────────────────────
async function handle911(command, userId, guild, client) {
  try {
    const config = await DispatchConfig.findOne({ guildId: guild.id });
    if (!config || !config.enabled) {
      return { tts: 'Dispatch is not configured on this server.', embed: null };
    }

    // Extract description from command — everything after "911" or "emergency"
    const description = command
      .replace(/nine\s+one\s+one/gi, '911')
      .replace(/.*?(?:911|emergency)[,\s]*/i, '')
      .trim() || 'No description provided';

    const callId = uuidv4().slice(0, 8).toUpperCase();
    const member = await guild.members.fetch(userId).catch(() => null);
    const username = member?.displayName || member?.user?.username || 'Unknown';

    // Save to MongoDB — RolePlayManager will pick this up
    const call = new EmergencyCall({
      guildId: guild.id,
      callId,
      issue: description,
      location: 'Unknown — via voice',
      reporterUsername: username,
      reporterId: userId,
      source: 'eco',
      status: 'active',
    });
    await call.save();

    // Post embed to dispatch channel
    const dispatchChannelId = config.dispatchChannelId || process.env.DISPATCH_CHANNEL_ID;
    if (dispatchChannelId) {
      const dispatchChannel = await client.channels.fetch(dispatchChannelId).catch(() => null);
      if (dispatchChannel) {
        const embed = new EmbedBuilder()
          .setTitle('🚨 911 Emergency Call')
          .setColor(0xff0000)
          .addFields(
            { name: 'Call ID', value: callId, inline: true },
            { name: 'Caller', value: username, inline: true },
            { name: 'Channel', value: process.env.CHANNEL_NAME || 'Unknown', inline: true },
            { name: 'Description', value: description },
          )
          .setFooter({ text: 'Submitted via Project Eco' })
          .setTimestamp();
        await dispatchChannel.send({ embeds: [embed] });
      }
    }

    return {
      tts: `Copy, 911 call submitted. Call ID ${callId.split('').join(' ')}. Units are being notified.`,
      embed: null,
    };
  } catch (err) {
    console.error(`[Eco Bot ${BOT_INDEX}] 911 error:`, err.message);
    return { tts: 'There was an error submitting that 911 call. Please try again.', embed: null };
  }
}

// ── Priority Request ──────────────────────────────────────────────────────────
async function handlePriorityRequest(command, userId, guild, client) {
  try {
    const priority = await Priority.findOne({ guildId: guild.id });
    if (!priority || !priority.enabled || !priority.channelId) {
      return { tts: 'Priority tracker is not set up on this server.', embed: null };
    }

    if (priority.priorityActive) {
      return { tts: 'A priority scene is already active. Stand by.', embed: null };
    }

    if (priority.cooldownEndsAt && priority.cooldownEndsAt > new Date()) {
      const remaining = Math.ceil((priority.cooldownEndsAt - new Date()) / 60000);
      return { tts: `Priority is on cooldown. ${remaining} minutes remaining.`, embed: null };
    }

    const member = await guild.members.fetch(userId).catch(() => null);
    const username = member?.displayName || member?.user?.username || 'Unknown';

    // Extract scene type from command if provided
    const sceneType = command
      .replace(/priority\s+request[,\s]*/i, '')
      .replace(/priority[,\s]*/i, '')
      .trim() || 'Scene requested via voice';

    // Save request to MongoDB
    const request = new PriorityRequest({
      guildId: guild.id,
      requesterId: userId,
      requesterUsername: username,
      sceneType,
      sceneReason: 'Submitted via Project Eco voice command',
      source: 'eco',
    });
    await request.save();

    // Post to priority channel
    const priorityChannel = await client.channels.fetch(priority.channelId).catch(() => null);
    if (priorityChannel) {
      const embed = new EmbedBuilder()
        .setTitle('🎬 Priority Request')
        .setColor(0xffaa00)
        .addFields(
          { name: 'Requested By', value: username, inline: true },
          { name: 'Channel', value: process.env.CHANNEL_NAME || 'Unknown', inline: true },
          { name: 'Scene Type', value: sceneType },
          { name: 'Note', value: 'Submitted via Project Eco voice command' },
        )
        .setFooter({ text: 'Project Eco' })
        .setTimestamp();
      await priorityChannel.send({ embeds: [embed] });
    }

    return {
      tts: `Copy, priority request submitted by ${username}. Waiting on host approval.`,
      embed: null,
    };
  } catch (err) {
    console.error(`[Eco Bot ${BOT_INDEX}] Priority request error:`, err.message);
    return { tts: 'There was an error submitting the priority request. Please try again.', embed: null };
  }
}

// ── CAD Lookup (plates and names) ─────────────────────────────────────────────
async function handleCADLookup(lookup, guild, client) {
  try {
    const result = await runCADLookup(guild.id, lookup);
    if (!result) return { tts: 'Could not process that lookup. Please try again.', embed: null };

    // Build embed for dispatch channel if found
    let embed = null;
    if (result.found && result.embed) {
      embed = new EmbedBuilder().setColor(result.embed.status === 'WANTED' ? 0xff0000 : 0x00cc66).setTimestamp();

      if (lookup.type === 'plate') {
        embed
          .setTitle(`🚗 Plate Run — ${result.embed.plate}`)
          .addFields(
            { name: 'Registered Owner', value: result.embed.owner || 'Unknown', inline: true },
            { name: 'Vehicle', value: result.embed.vehicleDesc || 'Unknown', inline: true },
            { name: 'Status', value: result.embed.status, inline: true },
            { name: 'License', value: result.embed.license, inline: true },
          );
        if (result.embed.hasBolo) {
          embed.addFields({ name: '⚠️ BOLO', value: result.embed.boloReason || 'Active BOLO' });
        }
      } else {
        embed
          .setTitle(`👤 Name Run — ${result.embed.name}`)
          .addFields(
            { name: 'Name', value: result.embed.name || 'Unknown', inline: true },
            { name: 'Status', value: result.embed.status, inline: true },
            { name: 'License', value: result.embed.license, inline: true },
          );
        if (result.embed.vehicles?.length > 0) {
          const vList = result.embed.vehicles.map(v => `${v.color || ''} ${v.make || ''} ${v.model || ''} — ${v.licensePlate || 'No Plate'}`.trim()).join('\n');
          embed.addFields({ name: 'Vehicles', value: vList });
        }
        if (result.embed.hasBolo) {
          embed.addFields({ name: '⚠️ BOLO', value: result.embed.boloReason || 'Active BOLO' });
        }
      }

      // Post embed to dispatch channel
      const config = await DispatchConfig.findOne({ guildId: guild.id });
      const dispatchChannelId = config?.dispatchChannelId || process.env.DISPATCH_CHANNEL_ID;
      if (dispatchChannelId) {
        const dispatchChannel = await client.channels.fetch(dispatchChannelId).catch(() => null);
        if (dispatchChannel) await dispatchChannel.send({ embeds: [embed] });
      }
    }

    return { tts: result.ttsResponse, embed };
  } catch (err) {
    console.error(`[Eco Bot ${BOT_INDEX}] CAD lookup error:`, err.message);
    return { tts: 'Error running that lookup. Please try again.', embed: null };
  }
}
