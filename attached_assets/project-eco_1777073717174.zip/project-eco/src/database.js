import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();

export async function connectDatabase() {
  try {
    const uri = process.env.MONGODB_URI;
    if (!uri || (!uri.startsWith('mongodb://') && !uri.startsWith('mongodb+srv://'))) {
      throw new Error('Invalid MONGODB_URI');
    }
    await mongoose.connect(uri);
    console.log(`[Eco Bot ${process.env.BOT_INDEX}] Connected to MongoDB`);
  } catch (error) {
    console.error(`[Eco Bot ${process.env.BOT_INDEX}] MongoDB error:`, error.message);
  }
}

mongoose.connection.on('disconnected', () => {
  console.log(`[Eco Bot ${process.env.BOT_INDEX}] MongoDB disconnected`);
});

mongoose.connection.on('error', (error) => {
  console.error(`[Eco Bot ${process.env.BOT_INDEX}] MongoDB error:`, error);
});
