import { registerTool, type ToolDefinition } from "./index";
import {
  autonomyEnabled,
  github,
  koyeb,
  recordAction,
  requireAutonomy,
} from "../jarvisAutonomy";
import { logger } from "../logger";

const ACCOUNT_PROP = {
  account: {
    type: "integer",
    enum: [1, 2],
    default: 1,
    description: "Which configured account to use: 1 (default, GITHUB_TOKEN/KOYEB_API_TOKEN) or 2 (GITHUB_TOKEN_2/KOYEB_API_TOKEN_2). Falls back to 1 if 2 is not configured.",
  },
} as const;

const REPO_PROP = {
  repo: {
    type: "string",
    description: "Optional 'owner/name' of any repo the token can access. Defaults to GITHUB_REPO. Use this to target other repos under the same account without setting another env var.",
  },
} as const;

/**
 * Wrap a tool's run() so every invocation:
 *   1. Checks the JARVIS_AUTONOMY kill switch
 *   2. Logs the action (success or failure) to the jarvis_actions audit table
 */
function autonomous<TParams, TResult>(
  def: ToolDefinition<TParams, TResult>,
): ToolDefinition<TParams, TResult> {
  const wrapped: ToolDefinition<TParams, TResult> = {
    ...def,
    async run(params: TParams) {
      const t0 = Date.now();
      try {
        requireAutonomy();
        const result = await def.run(params);
        await recordAction({
          tool: def.name,
          params,
          ok: true,
          result,
          durationMs: Date.now() - t0,
        });
        return result;
      } catch (err) {
        const error = err instanceof Error ? err.message : String(err);
        await recordAction({
          tool: def.name,
          params,
          ok: false,
          error,
          durationMs: Date.now() - t0,
        });
        throw err;
      }
    },
  };
  return wrapped;
}

export function registerAutonomyTools(): void {
  // GitHub --------------------------------------------------------------
  registerTool(
    autonomous({
      name: "github_list_repos",
      description: "List repositories the configured GitHub token can access (own + collaborator + org). Use this when the user asks about their other repos or wants to know what Jarvis can touch.",
      paramsSchema: {
        type: "object",
        properties: {
          perPage: { type: "integer", default: 30, minimum: 1, maximum: 100 },
          ...ACCOUNT_PROP,
        },
      },
      async run(params: unknown) {
        const { perPage = 30, account } = (params as { perPage?: number; account?: number }) ?? {};
        return github.listRepos(account, perPage);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "github_list_commits",
      description: "List the most recent commits on a repo branch.",
      paramsSchema: {
        type: "object",
        properties: {
          limit: { type: "integer", default: 10, minimum: 1, maximum: 50 },
          ...ACCOUNT_PROP,
          ...REPO_PROP,
        },
      },
      async run(params: unknown) {
        const { limit = 10, account, repo } = (params as { limit?: number; account?: number; repo?: string }) ?? {};
        return github.listCommits(limit, account, repo);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "github_read_file",
      description: "Read a file's contents from a repo.",
      paramsSchema: {
        type: "object",
        required: ["path"],
        properties: {
          path: { type: "string", description: "Repo-relative file path" },
          ref: { type: "string", description: "Branch, tag, or commit SHA (optional)" },
          ...ACCOUNT_PROP,
          ...REPO_PROP,
        },
      },
      async run(params: unknown) {
        const { path, ref, account, repo } = params as { path: string; ref?: string; account?: number; repo?: string };
        return github.readFile(path, ref, account, repo);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "github_write_file",
      description:
        "Create or update a file in a repo. Commits directly to the given branch (defaults to main).",
      paramsSchema: {
        type: "object",
        required: ["path", "content", "message"],
        properties: {
          path: { type: "string" },
          content: { type: "string" },
          message: { type: "string", description: "Commit message" },
          branch: { type: "string", description: "Target branch (default: main)" },
          ...ACCOUNT_PROP,
          ...REPO_PROP,
        },
      },
      async run(params: unknown) {
        const { path, content, message, branch, account, repo } = params as {
          path: string; content: string; message: string; branch?: string; account?: number; repo?: string;
        };
        return github.writeFile(path, content, message, branch, account, repo);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "github_create_branch",
      description: "Create a new branch off another branch (default: main).",
      paramsSchema: {
        type: "object",
        required: ["name"],
        properties: {
          name: { type: "string", description: "New branch name" },
          from: { type: "string", description: "Source branch (default: main)" },
          ...ACCOUNT_PROP,
          ...REPO_PROP,
        },
      },
      async run(params: unknown) {
        const { name, from, account, repo } = params as { name: string; from?: string; account?: number; repo?: string };
        return github.createBranch(name, from, account, repo);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "github_open_pr",
      description: "Open a pull request from `head` into `base` (default base: main).",
      paramsSchema: {
        type: "object",
        required: ["title", "head"],
        properties: {
          title: { type: "string" },
          body: { type: "string" },
          head: { type: "string", description: "Source branch" },
          base: { type: "string", description: "Target branch (default: main)" },
          ...ACCOUNT_PROP,
          ...REPO_PROP,
        },
      },
      async run(params: unknown) {
        const { title, body = "", head, base, account, repo } = params as {
          title: string; body?: string; head: string; base?: string; account?: number; repo?: string;
        };
        return github.openPR(title, body, head, base, account, repo);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "github_merge_pr",
      description: "Merge an open pull request by number.",
      paramsSchema: {
        type: "object",
        required: ["number"],
        properties: {
          number: { type: "integer" },
          method: { type: "string", enum: ["merge", "squash", "rebase"], default: "squash" },
          ...ACCOUNT_PROP,
          ...REPO_PROP,
        },
      },
      async run(params: unknown) {
        const { number, method = "squash", account, repo } = params as {
          number: number; method?: "merge" | "squash" | "rebase"; account?: number; repo?: string;
        };
        return github.mergePR(number, method, account, repo);
      },
    }),
  );

  // Koyeb ---------------------------------------------------------------
  registerTool(
    autonomous({
      name: "koyeb_list_services",
      description: "List Koyeb services for a configured token. Pass account: 'all' to combine both accounts.",
      paramsSchema: {
        type: "object",
        properties: {
          account: {
            oneOf: [
              { type: "integer", enum: [1, 2], default: 1 },
              { type: "string", enum: ["all"] },
            ],
            description: "1, 2, or 'all' to merge both accounts.",
          },
        },
      },
      async run(params: unknown) {
        const { account } = (params as { account?: number | "all" }) ?? {};
        if (account === "all") {
          const accs = koyeb.whichAccounts();
          const all = await Promise.all(accs.map((a) => koyeb.listServices(a)));
          return all.flat();
        }
        return koyeb.listServices(typeof account === "number" ? account : 1);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "koyeb_get_logs",
      description: "Fetch the most recent log lines from a Koyeb service.",
      paramsSchema: {
        type: "object",
        required: ["serviceId"],
        properties: {
          serviceId: { type: "string" },
          limit: { type: "integer", default: 100, minimum: 1, maximum: 500 },
          ...ACCOUNT_PROP,
        },
      },
      async run(params: unknown) {
        const { serviceId, limit = 100, account } = params as { serviceId: string; limit?: number; account?: number };
        return koyeb.getRecentLogs(serviceId, limit, account);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "koyeb_redeploy",
      description: "Trigger a redeploy of a Koyeb service.",
      paramsSchema: {
        type: "object",
        required: ["serviceId"],
        properties: { serviceId: { type: "string" }, ...ACCOUNT_PROP },
      },
      async run(params: unknown) {
        const { serviceId, account } = params as { serviceId: string; account?: number };
        return koyeb.redeploy(serviceId, account);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "koyeb_pause_service",
      description: "Pause a Koyeb service (stops it without deleting).",
      paramsSchema: {
        type: "object",
        required: ["serviceId"],
        properties: { serviceId: { type: "string" }, ...ACCOUNT_PROP },
      },
      async run(params: unknown) {
        const { serviceId, account } = params as { serviceId: string; account?: number };
        return koyeb.pause(serviceId, account);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "koyeb_resume_service",
      description: "Resume a paused Koyeb service.",
      paramsSchema: {
        type: "object",
        required: ["serviceId"],
        properties: { serviceId: { type: "string" }, ...ACCOUNT_PROP },
      },
      async run(params: unknown) {
        const { serviceId, account } = params as { serviceId: string; account?: number };
        return koyeb.resume(serviceId, account);
      },
    }),
  );

  registerTool(
    autonomous({
      name: "koyeb_delete_service",
      description: "PERMANENTLY delete a Koyeb service. Cannot be undone.",
      paramsSchema: {
        type: "object",
        required: ["serviceId"],
        properties: { serviceId: { type: "string" }, ...ACCOUNT_PROP },
      },
      async run(params: unknown) {
        const { serviceId, account } = params as { serviceId: string; account?: number };
        return koyeb.deleteService(serviceId, account);
      },
    }),
  );

  logger.info(
    {
      autonomy: autonomyEnabled() ? "on" : "off",
      githubAccounts: github.whichAccounts(),
      koyebAccounts: koyeb.whichAccounts(),
    },
    "Jarvis autonomy tools registered (GitHub + Koyeb)",
  );
}
